<?php

    $con =mysqli_connect('localhost','root','','moviebook');
    if($con){
    }
    else{
        echo"error";
    }
    ?>